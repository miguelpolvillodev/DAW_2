# Cálculos y validación.
