# Reglas del proyecto de práctica

- Usar Python 3.13 o superior y conservar los type hints.
- Mantener las firmas, la estructura y el contrato del enunciado.
- Dominio no importa servicios ni infraestructura.
- No añadir frameworks, bases de datos ni dependencias a la aplicación.
- Usar importaciones absolutas salvo la API pública ya preparada.
- Capturar errores específicos; nunca BaseException.
- Conservar wraps y el resultado de las funciones decoradas.
- En la auditoría inicial, leer y proponer; no modificar archivos.
- Informar de las pruebas ejecutadas y las comprobaciones pendientes.
