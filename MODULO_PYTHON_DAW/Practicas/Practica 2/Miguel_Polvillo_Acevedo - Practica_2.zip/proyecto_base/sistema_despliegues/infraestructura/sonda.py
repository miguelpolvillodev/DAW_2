from collections.abc import Callable
from functools import wraps


# Lectura guiada: este código se entrega completo, sin red real.
def reintentar(func: Callable[[int], str]) -> Callable[[], str]:
    @wraps(func)
    def wrapper() -> str:
        for intento in range(1, 4):
            try:
                return func(intento)
            except ConnectionError:
                print(f"Sonda: fallo de conexión en intento {intento}")
        raise ConnectionError("La sonda falló después de 3 intentos")
    return wrapper


@reintentar
def consultar_servicio(intento: int) -> str:
    if intento < 3:
        raise ConnectionError("Fallo temporal simulado")
    return "Servicio disponible"


if __name__ == "__main__":
    print(consultar_servicio())
