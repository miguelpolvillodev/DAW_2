from sistema_despliegues.dominio.errores import DatosInvalidosError
from sistema_despliegues.dominio.modelos import Configuracion


def leer_configuracion() -> Configuracion:
    """Entrada y conversiones del día 1; se entrega ya implementada."""
    nombre: str = input("Nombre del servicio: ").strip()
    entorno: str = input("Entorno (desarrollo/staging/produccion): ").strip().lower()
    try:
        ram_gb: int = int(input("RAM en GB: "))
        latencia_ms: float = float(input("Latencia en ms: "))
        presupuesto_diario: float = float(input("Presupuesto diario en euros: "))
    except ValueError as error:
        # Convertimos un fallo técnico y conservamos su causa.
        raise DatosInvalidosError("RAM, latencia o presupuesto no numéricos") from error

    respuesta_ssl: str = input("SSL activo (s/n): ").strip().lower()
    if respuesta_ssl not in ("s", "n"):
        raise DatosInvalidosError("La respuesta SSL debe ser s o n")

    return {
        "nombre": nombre,
        "entorno": entorno,
        "ram_gb": ram_gb,
        "latencia_ms": latencia_ms,
        "presupuesto_diario": presupuesto_diario,
        "ssl_activo": respuesta_ssl == "s",
    }
