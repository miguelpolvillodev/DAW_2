def calcular_coste_hora(*partidas: float) -> float:
    """Recibe presupuestos diarios y devuelve su suma dividida entre 24."""
    # TODO 2: partidas es una tupla; sum(()) devuelve 0, así que 0 / 24 = 0.0.
    return sum(partidas) / 24


def calcular_recursos(
    peticiones: int, capacidad: int = 100
) -> tuple[int, int]:
    """Devuelve contenedores completos y peticiones sobrantes."""
    if peticiones < 0 or capacidad <= 0:
        raise ValueError("Peticiones no negativas y capacidad positiva")
    # TODO 3: // da los contenedores completos y % las peticiones sobrantes.
    completos: int = peticiones // capacidad
    sobrantes: int = peticiones % capacidad
    return completos, sobrantes
