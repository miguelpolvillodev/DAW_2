# Entidades y errores de negocio.
