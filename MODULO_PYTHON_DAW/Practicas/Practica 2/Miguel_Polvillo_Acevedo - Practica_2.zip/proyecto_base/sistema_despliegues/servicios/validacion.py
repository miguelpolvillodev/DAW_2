from math import isfinite

from sistema_despliegues.dominio.errores import (
    DatosInvalidosError,
    DespliegueNoAptoError,
)
from sistema_despliegues.dominio.modelos import Configuracion
from sistema_despliegues.servicios.decoradores import temporizador


@temporizador
def validar_despliegue(config: Configuracion) -> None:
    """Devuelve None si es apto; en los demás casos lanza un error."""
    if not config["nombre"].strip():
        raise DatosInvalidosError("El nombre no puede estar vacío")
    if config["entorno"] not in ("desarrollo", "staging", "produccion"):
        raise DatosInvalidosError("Entorno desconocido")
    if (
        config["ram_gb"] <= 0
        or config["latencia_ms"] < 0
        or config["presupuesto_diario"] < 0
        or not isfinite(config["latencia_ms"])
        or not isfinite(config["presupuesto_diario"])
    ):
        raise DatosInvalidosError("RAM positiva y valores decimales finitos no negativos")

    # TODO 5: reglas de aptitud combinadas con or.
    produccion_apta: bool = (
        config["entorno"] == "produccion"
        and config["ram_gb"] >= 8
        and config["latencia_ms"] <= 50.0
        and config["ssl_activo"]
    )
    pruebas_aptas: bool = (
        config["entorno"] in ("desarrollo", "staging")
        and config["ram_gb"] >= 2
    )

    if not (produccion_apta or pruebas_aptas):
        motivo: str
        if config["entorno"] == "produccion":
            motivo = "producción exige RAM >= 8 GB, latencia <= 50 ms y SSL activo"
        else:
            motivo = "desarrollo y staging exigen RAM >= 2 GB"
        raise DespliegueNoAptoError(config["nombre"], motivo)
