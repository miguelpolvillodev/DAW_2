import time
from collections.abc import Callable
from functools import wraps

from sistema_despliegues.dominio.modelos import Configuracion


def temporizador(
    func: Callable[[Configuracion], None],
) -> Callable[[Configuracion], None]:
    # TODO 4: decorador con clausura, wraps y finally.
    @wraps(func)
    def wrapper(config: Configuracion) -> None:
        inicio: float = time.perf_counter()
        try:
            func(config)
        finally:
            # Se ejecuta tanto si func termina como si lanza una excepción.
            duracion: float = time.perf_counter() - inicio
            print(f"[MÉTRICA] {func.__name__}: {duracion:.6f} s")

    return wrapper
