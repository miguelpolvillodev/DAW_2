import unittest
from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch

from sistema_despliegues import calcular_coste_hora, calcular_recursos, validar_despliegue
from sistema_despliegues.dominio.errores import (
    DatosInvalidosError,
    DespliegueNoAptoError,
    ErrorDespliegue,
)
from sistema_despliegues.dominio.modelos import Configuracion
from sistema_despliegues.infraestructura.entrada import leer_configuracion
from sistema_despliegues.infraestructura.salida import registrar_evento
from sistema_despliegues.infraestructura.sonda import consultar_servicio, reintentar


def configuracion(**cambios: object) -> Configuracion:
    datos: Configuracion = {
        "nombre": "api_clase", "entorno": "produccion", "ram_gb": 8,
        "latencia_ms": 50.0, "presupuesto_diario": 48.0, "ssl_activo": True,
    }
    # Helper solo para pruebas: claves y valores verificados explícitamente.
    for clave, valor in cambios.items():
        if clave in ("nombre", "entorno") and isinstance(valor, str):
            if clave == "nombre":
                datos["nombre"] = valor
            else:
                datos["entorno"] = valor
        elif clave == "ram_gb" and isinstance(valor, int):
            datos["ram_gb"] = valor
        elif clave == "latencia_ms" and isinstance(valor, (int, float)):
            datos["latencia_ms"] = float(valor)
        elif clave == "presupuesto_diario" and isinstance(valor, (int, float)):
            datos["presupuesto_diario"] = float(valor)
        elif clave == "ssl_activo" and isinstance(valor, bool):
            datos["ssl_activo"] = valor
        else:
            raise ValueError(f"Cambio de prueba no admitido: {clave}")
    return datos


class TestContrato(unittest.TestCase):
    def validar_sin_salida(self, datos: Configuracion) -> None:
        with redirect_stdout(StringIO()):
            validar_despliegue(datos)

    def test_coste_variable(self) -> None:
        self.assertEqual(calcular_coste_hora(), 0.0)
        self.assertAlmostEqual(calcular_coste_hora(24.0, 48.0), 3.0)

    def test_recursos(self) -> None:
        self.assertEqual(calcular_recursos(1050), (10, 50))
        self.assertEqual(calcular_recursos(100), (1, 0))
        self.assertEqual(calcular_recursos(0), (0, 0))
        self.assertEqual(calcular_recursos(1050, 200), (5, 50))

    def test_recursos_invalidos(self) -> None:
        for peticiones, capacidad in ((-1, 100), (1, 0)):
            with self.subTest(peticiones=peticiones, capacidad=capacidad):
                with self.assertRaises(ValueError):
                    calcular_recursos(peticiones, capacidad)

    def test_produccion_limite_apta(self) -> None:
        self.validar_sin_salida(configuracion())

    def test_pruebas_no_exigen_ssl_ni_latencia_baja(self) -> None:
        for entorno in ("desarrollo", "staging"):
            self.validar_sin_salida(configuracion(
                entorno=entorno, ram_gb=2, latencia_ms=200.0, ssl_activo=False
            ))

    def test_produccion_no_apta(self) -> None:
        for datos in (
            configuracion(ram_gb=7), configuracion(latencia_ms=50.1),
            configuracion(ssl_activo=False),
        ):
            with self.assertRaises(DespliegueNoAptoError) as captura:
                self.validar_sin_salida(datos)
            self.assertEqual(captura.exception.nombre, "api_clase")
            self.assertTrue(captura.exception.motivo)

    def test_pruebas_ram_insuficiente(self) -> None:
        with self.assertRaises(DespliegueNoAptoError):
            self.validar_sin_salida(configuracion(entorno="staging", ram_gb=1))

    def test_datos_invalidos(self) -> None:
        for datos in (
            configuracion(nombre=" "), configuracion(entorno="otro"),
            configuracion(ram_gb=0), configuracion(latencia_ms=-1.0),
            configuracion(presupuesto_diario=-1.0),
            configuracion(latencia_ms=float("nan")),
        ):
            with self.assertRaises(DatosInvalidosError):
                self.validar_sin_salida(datos)

    def test_presupuesto_cero_permitido(self) -> None:
        self.validar_sin_salida(configuracion(presupuesto_diario=0.0))

    def test_error_con_contexto(self) -> None:
        error: DespliegueNoAptoError = DespliegueNoAptoError("api", "RAM insuficiente")
        self.assertIsInstance(error, ErrorDespliegue)
        self.assertEqual(error.nombre, "api")
        self.assertEqual(error.motivo, "RAM insuficiente")
        self.assertIn("RAM insuficiente", str(error))

    def test_registro_metadatos(self) -> None:
        self.assertEqual(registrar_evento("AUDIT", usuario="ana", apto=True),
                         "AUDIT | usuario=ana, apto=True")
        self.assertEqual(registrar_evento("AUDIT"), "AUDIT | ")

    def test_wraps_y_metrica_en_error(self) -> None:
        self.assertEqual(validar_despliegue.__name__, "validar_despliegue")
        with redirect_stdout(StringIO()) as salida:
            with self.assertRaises(DespliegueNoAptoError):
                validar_despliegue(configuracion(ssl_activo=False))
        self.assertIn("[MÉTRICA]", salida.getvalue())

    def test_encadenamiento_conversion(self) -> None:
        with patch("builtins.input", side_effect=["api", "produccion", "ocho"]):
            with self.assertRaises(DatosInvalidosError) as captura:
                leer_configuracion()
        self.assertIsInstance(captura.exception.__cause__, ValueError)

    def test_sonda_simulada(self) -> None:
        with redirect_stdout(StringIO()):
            self.assertEqual(consultar_servicio(), "Servicio disponible")

    def test_sonda_no_reintenta_reglas_de_negocio(self) -> None:
        llamadas: list[int] = []
        def falla(intento: int) -> str:
            llamadas.append(intento)
            raise ValueError("No es fallo de red")
        with self.assertRaises(ValueError):
            reintentar(falla)()
        self.assertEqual(llamadas, [1])


if __name__ == "__main__":
    unittest.main()
