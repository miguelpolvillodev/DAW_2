# Validador modular de despliegues

Abrir esta carpeta en VS Code. Seleccionar Python 3.13 o superior.
Ejecutar desde esta raíz, no desde una subcarpeta del paquete.

```powershell
python --version
python main.py
python -m unittest discover -s tests -v
python -m sistema_despliegues.infraestructura.sonda
```

El proyecto base tiene seis TODO numerados en cinco archivos. Antes de completarlos,
algunas pruebas fallan y main muestra PENDIENTE. El TODO 4 tiene un retorno provisional que también hay que sustituir. Ese es el punto de partida esperado.
La aplicación solo utiliza la biblioteca estándar.
Los tests usan unittest y se pueden ejecutar también con pytest sin duplicarlos.
Las firmas y el contrato se encuentran en la guía del ejercicio.
