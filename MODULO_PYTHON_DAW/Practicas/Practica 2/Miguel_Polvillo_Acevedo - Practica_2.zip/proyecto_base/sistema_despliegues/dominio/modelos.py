from typing import TypedDict


# Un TypedDict describe las claves de un diccionario; no crea objetos nuevos.
# Este archivo se entrega completo: solo hay que usar sus campos.
class Configuracion(TypedDict):
    nombre: str
    entorno: str
    ram_gb: int
    latencia_ms: float
    presupuesto_diario: float
    ssl_activo: bool
