from sistema_despliegues import (
    calcular_coste_hora,
    calcular_recursos,
    validar_despliegue,
)
from sistema_despliegues.dominio.errores import (
    DatosInvalidosError,
    DespliegueNoAptoError,
)
from sistema_despliegues.dominio.modelos import Configuracion
from sistema_despliegues.infraestructura.entrada import leer_configuracion
from sistema_despliegues.infraestructura.salida import (
    mostrar_resumen,
    registrar_evento,
)


def main() -> None:
    try:
        config: Configuracion = leer_configuracion()
    except DatosInvalidosError as error:
        print(f"DATOS INCORRECTOS: {error}")
        return

    apto: bool = True
    try:
        validar_despliegue(config)
    except DespliegueNoAptoError as error:
        apto = False
        print(f"NO APTO: {error.motivo}")
    except DatosInvalidosError as error:
        print(f"DATOS INCORRECTOS: {error}")
        return
    except NotImplementedError as error:
        # Mensaje útil en el proyecto base; no se alcanza en la solución.
        print(f"PENDIENTE: {error}")
        return

    coste_hora: float = calcular_coste_hora(config["presupuesto_diario"])
    completos: int
    sobrantes: int
    completos, sobrantes = calcular_recursos(1050)
    mostrar_resumen(
        config["nombre"], coste_hora, completos, sobrantes, apto=apto
    )
    print(registrar_evento("VALIDACION", servicio=config["nombre"], apto=apto))


if __name__ == "__main__":
    main()
