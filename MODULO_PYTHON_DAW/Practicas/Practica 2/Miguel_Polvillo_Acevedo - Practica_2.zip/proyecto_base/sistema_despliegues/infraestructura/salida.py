def registrar_evento(evento: str, **metadatos: object) -> str:
    """Crea un registro de texto con argumentos nombrados variables."""
    detalles: str = ", ".join(
        f"{clave}={valor}" for clave, valor in metadatos.items()
    )
    # TODO 6: evento y detalles separados por " | ".
    return f"{evento} | {detalles}"


def mostrar_resumen(
    nombre: str,
    coste_hora: float,
    completos: int,
    sobrantes: int,
    *,
    apto: bool,
) -> None:
    # apto es obligatorio por nombre; no hay *args en esta firma.
    print(f"Servicio: {nombre}")
    print(f"Coste por hora: {coste_hora:.2f} euros")
    print(f"Contenedores completos: {completos}")
    print(f"Peticiones sobrantes: {sobrantes}")
    print(f"Despliegue apto: {apto}")
