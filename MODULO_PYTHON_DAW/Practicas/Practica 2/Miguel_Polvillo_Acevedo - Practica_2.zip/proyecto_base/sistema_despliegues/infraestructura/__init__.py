# Entrada, salida y simulaciones.
