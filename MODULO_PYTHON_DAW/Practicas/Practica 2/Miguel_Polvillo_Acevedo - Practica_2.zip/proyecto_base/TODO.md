# Práctica 2 — TODOs resueltos

1. **errores.py**: guardo `self.nombre` y `self.motivo` y llamo a `super().__init__(...)` con un mensaje que incluye los dos. Así `main` puede leer `error.motivo` directamente, sin tener que analizar el texto del mensaje.

2. **calcular_coste_hora**: devuelve `sum(partidas) / 24`. Sin argumentos, `sum(())` vale 0, así que el resultado es 0.0 sin necesidad de un `if`.

3. **calcular_recursos**: usa `peticiones // capacidad` y `peticiones % capacidad`, y devuelve los dos valores como tupla.

4. **temporizador**: `wrapper` lleva `@wraps(func)`, guarda `perf_counter()` al empezar, llama a `func(config)` dentro de un `try` e imprime `[MÉTRICA]` en el `finally`. El `finally` es lo que hace que la métrica salga también cuando se lanza `DespliegueNoAptoError`. `@wraps` es lo que conserva el nombre `validar_despliegue`. Por último, se devuelve `wrapper` sin llamarlo.

5. **validacion.py**: define `produccion_apta` (cuatro condiciones unidas con `and`) y `pruebas_aptas` (entorno en desarrollo o staging, y RAM >= 2). Si `not (produccion_apta or pruebas_aptas)`, lanza el error con un motivo distinto según el entorno.

6. **registrar_evento**: devuelve `f"{evento} | {detalles}"`. Sin metadatos sale `"AUDIT | "`, que es justo lo que pide el test.