class ErrorDespliegue(Exception):
    """Clase base de los errores propios de la aplicación."""


class DatosInvalidosError(ErrorDespliegue):
    """Datos con formato o valores no admitidos."""


class DespliegueNoAptoError(ErrorDespliegue):
    """Datos válidos que incumplen las reglas de infraestructura."""

    def __init__(self, nombre: str, motivo: str) -> None:
        # TODO 1: atributos tipados para que la captura lea error.motivo.
        self.nombre: str = nombre
        self.motivo: str = motivo
        super().__init__(f"Despliegue '{nombre}' no apto: {motivo}")
